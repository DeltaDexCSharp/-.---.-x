﻿namespace ᴰ
{
    public static class Intializer
    {
        [STAThread]
        static void Main()
        {
            YourClass.Initiate();       
        }
    }
}