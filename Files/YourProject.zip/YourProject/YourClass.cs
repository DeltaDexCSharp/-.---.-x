﻿using ᴰ;

namespace ᴰ
{
    public class YourClass
    {
        public static void Initiate()
        {
            ᴰ.ᴱx.initForm(ᴰ.ᴱx.mainForm, 400, 200, "FormName", "WindowTitle"); //Main form settings set to ᴰ.ᴱx.mainForm Object the intended main form
            ᴰ.ᴱᴸᵀᴬ.TargetName = "WindowTitle"; // Match this to your WindowTitle for correct functionality else error in other functionality of ᴰ.ᴱᴸᵀᴬ
            ᴰ.ᴱx.Start();
            //The above settings and layout create a basic borderless form with no control for help and features see GitHub
        }

    }
}
